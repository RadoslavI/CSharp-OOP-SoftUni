﻿namespace Gym.Repositories
{
    public interface IRepository
    {
    }
}